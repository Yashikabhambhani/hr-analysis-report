# HR POWER BI REPORT
![Alt Text](https://miro.medium.com/v2/resize:fit:828/1*Dn5fU1c8R_UZCx1GSLrjTg.gif)

In this project, we conduct an end-to-end analysis on the human resources dataset consisting of two tables. We use the Power BI tool for this.
You can access all stages and details of the prepared report on [my Medium profile](https://medium.com/@gokcencngz/hr-dashboard-using-powerbi-b973f2c0750e).